package com.example.appkio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


public class pantalla_intent_cardview extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_iniciocardview);


    }
}
