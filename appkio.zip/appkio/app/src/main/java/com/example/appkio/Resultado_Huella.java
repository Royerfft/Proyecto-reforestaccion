package com.example.appkio;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Resultado_Huella extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_huella);
    }
}